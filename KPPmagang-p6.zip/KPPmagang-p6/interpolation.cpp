#include "interpolation.h"
#include <algorithm>
#include <cmath>

int interpolate(double angle) {
    // sudut valid RX-28: -150 sampai 150
    angle = std::clamp(angle, -150.0, 150.0);

    // linear dari [-150, 150] ke [0, 1023]
    double digital_unit = (angle + 150.0) * 1023.0 / 300.0;

    return static_cast<int>(std::lround(digital_unit));
}

std::vector<int> interpolate_list(const std::vector<double>& angles) {
    std::vector<int> digital_units;
    digital_units.reserve(angles.size());
    for (double angle : angles) {
        digital_units.push_back(interpolate(angle));
    }
    return digital_units;
}    